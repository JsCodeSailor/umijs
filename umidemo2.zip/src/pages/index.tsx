import React from 'react';
import styles from './index.css';
import { connect } from 'dva';

@connect(state => {
  console.log('state',state);
  return{
    name: state.todo.name,
  }
})
export default class Demo extends React.Component {
  changeName = () => {
    this.props.dispatch({
      type:'todo/changeName',
      payload:{
        name:`i'm changed!`
      }
    })
  };
  render() {
    return (
      <div>
        <h1>Hello, {this.props.name}!</h1>
        <button onClick={this.changeName}>Change Name</button>
      </div>
    );
  }
}
