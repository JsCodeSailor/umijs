export default {
    namespace: 'demo',
    state: {
      name: 333,
      age: 444,
    },
    reducers: {
      setState(state, { payload }) {
        return {
          ...state,
          ...payload,
        };
      },
    },
    effects: {
      *changeName({ payload }, { put }) {
          yield put({
              type:'setState',
              payload:{
                  name:payload.name,
              }
          })
      },
    },
  };
  